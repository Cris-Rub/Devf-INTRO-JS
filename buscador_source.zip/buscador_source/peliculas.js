const peliculas = [
	{
		nombre: 'Romance a la carta',
		genero: 'fantasia', 
		year: 1940,
		descripcion: 'Es el noble líder de los Autobots. Su misión consiste en luchar contra los Decepticons y detenerlos. Su forma alternativa es un camión Peterbilt rojo y azul. La voz es de Peter Cullen.',
		image: './338.jpeg' 
	},
	{
		nombre: 'el resplandor',
		genero: 'suspenso', 
		year: 1960,
		descripcion: 'Es el noble líder de los Autobots. Su misión consiste en luchar contra los Decepticons y detenerlos. Su forma alternativa es un camión Peterbilt rojo y azul. La voz es de Peter Cullen.',
		image: './338.jpeg' 
	},
	{
		nombre: 'titanic',
		genero: 'musical', 
		year: 1950,
		descripcion: 'Es el noble líder de los Autobots. Su misión consiste en luchar contra los Decepticons y detenerlos. Su forma alternativa es un camión Peterbilt rojo y azul. La voz es de Peter Cullen.',
		image: './338.jpeg' 
	},
	{
		nombre: 'coco',
		genero: 'fantasia', 
		year: 1960,
		descripcion: 'Es el noble líder de los Autobots. Su misión consiste en luchar contra los Decepticons y detenerlos. Su forma alternativa es un camión Peterbilt rojo y azul. La voz es de Peter Cullen.',
		image: './338.jpeg' 
	},
	{
		nombre: 'encanto',
		genero: 'fantasia', 
		year: 1960,
		descripcion: 'Es el noble líder de los Autobots. Su misión consiste en luchar contra los Decepticons y detenerlos. Su forma alternativa es un camión Peterbilt rojo y azul. La voz es de Peter Cullen.',
		image: './338.jpeg' 
	},
	{
		nombre: 'john wick',
		genero: 'suspenso', 
		year: 1940,
		descripcion: 'Es el noble líder de los Autobots. Su misión consiste en luchar contra los Decepticons y detenerlos. Su forma alternativa es un camión Peterbilt rojo y azul. La voz es de Peter Cullen.',
		image: './338.jpeg' 
	},
	{
		nombre: 'transformers',
		genero: 'musical', 
		year: 1950,
		descripcion: 'Es el noble líder de los Autobots. Su misión consiste en luchar contra los Decepticons y detenerlos. Su forma alternativa es un camión Peterbilt rojo y azul. La voz es de Peter Cullen.',
		image: './338.jpeg' 
	}
];
